<template>
    <div>
        <footer class="bg-primary-900 bg-opacity-20 w-full  p-10 grid lg:grid-cols-3 gap-y-4 gap-x-16 rounded-t-lg">
            
            <div class="text-primary-950 justify-self-center">
                <h3 class="text-xl font-bold mb-2">درباره ما</h3>
                <p>در دنیای امروز، کتاب‌ها نه تنها دریچه‌ای به دانش و تفکر جدید هستند، بلکه راهی برای افزایش خلاقیت، آرامش ذهن و تقویت قدرت تخیل محسوب می‌شوند. همان‌طور که <strong>فرانسیس بیکن</strong> گفته است:<br><strong>"خواندن، انسان را کامل می‌سازد؛ گفت‌وگو، انسان را حاضر جواب؛ و نوشتن، انسان را دقیق."</strong></p>
                <p>ما در این فروشگاه تلاش می‌کنیم تا با ارائه مجموعه‌ای از بهترین و متنوع‌ترین کتاب‌ها، امکان دستیابی به این منبع ارزشمند دانش و لذت را برای شما فراهم کنیم.</p>
            </div>

            <div class="text-primary-950 justify-self-center ">
                <h3 class="text-xl font-bold mb-2">چرا از ما خرید کنید؟</h3>
                <ul class="list-disc">
                    <li style="text-align: right;"><strong>ارسال سریع و ایمن:</strong> کتاب&zwnj;های شما با بسته&zwnj;بندی مطمئن و ارسال سریع به دستتان می&zwnj;رسند.</li>
                    <li style="text-align: right;"><strong>ضمانت کیفیت:</strong> ما کیفیت فیزیکی و اصالت تمامی کتاب&zwnj;ها را تضمین می&zwnj;کنیم.</li>
                    <li style="text-align: right;"><strong>تخفیف&zwnj;های ویژه:</strong> همیشه می&zwnj;توانید از تخفیف&zwnj;ها و پیشنهادات ویژه ما بهره&zwnj;مند شوید.</li>
                    <li style="text-align: right;"><strong>پشتیبانی 24/7:</strong> در هر لحظه از خرید، ما در کنار شما هستیم و به سوالات شما پاسخ می&zwnj;دهیم.</li>
                </ul>
            </div>

            <div class="text-primary-950  justify-self-center text-center">
                <h3 class="text-xl font-bold mb-2">گواهینامه ها</h3>
                <img class="bg-white rounded-lg mt-8" src="/images/certificates/logo.png" alt="">
            </div>

        </footer>
    </div>
</template>