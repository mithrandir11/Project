<template>
    <div class="container mx-auto px-1 lg:px-0">
        <Header/>
        <slot/>
        <Footer/>
    </div>
</template>